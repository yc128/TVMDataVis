import os
import sqlite3
from sqlite3 import Error
from JSON_reader import read_json_objects
import store_json_to_db
import db_manager
import db_table_names


database_path = os.path.join(os.path.dirname(__file__), '..', 'sample_database.db')

db_manager.create_tables(database_path)

conn = None
try:
    conn = sqlite3.connect(database_path)
except Error as e:
    print("create connection err:")
    print(e)

json_path = '../profiler_output.json'

res = read_json_objects(json_path)

store_json_to_db.insert_json_data(conn, res)
res_from_db = db_manager.fetch_data_as_dict(conn, db_table_names.table_benchmark)

print("data fetch from DB: ")
for row in res_from_db:
    print(row)

conn.close()
