import sqlite3
from sqlite3 import Error


def create_connection(db_file):
    conn = None
    try:
        conn = sqlite3.connect(db_file)
        return conn
    except Error as e:
        print("create connection err:")
        print(e)

    return conn


def create_table(conn, create_table_sql):
    try:
        c = conn.cursor()
        c.execute(create_table_sql)
    except Error as e:
        print("create table err on: ", create_table_sql)
        print(e)


def create_tables(database):
    # SQLite path
    conn = create_connection(database)

    if conn is not None:
        # create Benchmark table
        sql_create_benchmark_table = '''
        CREATE TABLE IF NOT EXISTS Benchmark (
            RunId VARCHAR PRIMARY KEY,
            TOTAL_TASK_GRAPH_TIME INT,
            COPY_IN_TIME INT,
            TOTAL_DISPATCH_DATA_TRANSFER_TIME INT,
            COPY_OUT_TIME INT,
            TOTAL_KERNEL_TIME INT,
            TOTAL_DISPATCH_KERNEL_TIME INT,
            TOTAL_COPY_IN_SIZE_BYTES INT,
            TOTAL_COPY_OUT_SIZE_BYTES INT,
            DRIVER VARCHAR,
            METHOD VARCHAR,
            DEVICE_ID VARCHAR,
            DEVICE VARCHAR,
            TOTAL_COPY_IN_SIZE_BYTES_R INT,
            TASK_KERNEL_TIME TIME
        )
        '''

        # Create run table
        sql_create_run_table = '''
        CREATE TABLE IF NOT EXISTS Run (
            RunID2 VARCHAR PRIMARY KEY,
            Date DATE,
            Time TIME,
            DataSize INT,
            Speed INT,
            CommitPoint VARCHAR,
            DeviceID VARCHAR,
            FOREIGN KEY(DeviceID) REFERENCES DeviceInfo(DeviceID)
        )
        '''

        # DeviceInfo
        sql_create_device_info_table = '''
        CREATE TABLE IF NOT EXISTS DeviceInfo (
            DeviceID VARCHAR PRIMARY KEY,
            DeviceName VARCHAR
        )
        '''

        # SoftwareInfo
        sql_create_software_info_table = '''
        CREATE TABLE IF NOT EXISTS SoftwareInfo (
            DeviceID INT PRIMARY KEY,
            OSType VARCHAR,
            OSVersion VARCHAR,
            JVM VARCHAR
        )
        '''

        # HardwareInfo
        sql_create_hardware_info_table = '''
        CREATE TABLE IF NOT EXISTS HardwareInfo (
            DeviceID INT PRIMARY KEY,
            Cores INT,
            GlobalMemory INT,
            BlockThreads INT,
            Vendor VARCHAR,
            Type VARCHAR,
            DriverType VARCHAR,
            DriverVersion VARCHAR,
            WorkgroupConfiguration VARCHAR
        )
        '''

        # create all tables
        create_table(conn, sql_create_benchmark_table)
        create_table(conn, sql_create_run_table)
        create_table(conn, sql_create_device_info_table)
        create_table(conn, sql_create_software_info_table)
        create_table(conn, sql_create_hardware_info_table)

        # change commit
        conn.commit()

        # close
        conn.close()
    else:
        print("Error! cannot create DB connection.")


def fetch_data(conn, table_name):
    """
    fetch table from db

    :param conn: db connection
    :param table_name: table name
    :return: list including all lines of this table
    """

    cur = conn.cursor()
    cur.execute(f"SELECT * FROM {table_name}")
    rows = cur.fetchall()
    cur.close()
    return rows


def fetch_data_as_dict(conn, table_name):
    """
    fetch data from table, return as dict pattern

    """
    conn.row_factory = sqlite3.Row  # set row_factory to output row
    cur = conn.cursor()
    cur.execute(f"SELECT * FROM {table_name}")
    rows = [dict(row) for row in cur.fetchall()]
    cur.close()
    return rows


