import sqlite3
import json


def insert_json_data(db_conn, json_results):
    """
    将解析过的JSON数据插入到数据库中。

    :param db_conn: 数据库连接对象
    :param json_results: 包含JSON数据的列表
    """
    cur = db_conn.cursor()

    for idx, data in enumerate(json_results):
        # 为Benchmark表准备数据
        benchmark_data = (
            idx,  # 假设RunId就是0, 1, 2, 3, ...
            data.get('TOTAL_TASK_GRAPH_TIME', None),
            data.get('COPY_IN_TIME', None),
            data.get('COPY_OUT_TIME', None),
            data.get('TOTAL_KERNEL_TIME', None),
            data.get('TOTAL_COPY_IN_SIZE_BYTES', None),
            data.get('TOTAL_COPY_OUT_SIZE_BYTES', None),
            data.get('s0.t0', {}).get('DRIVER', None),
            data.get('s0.t0', {}).get('METHOD', None),
            data.get('s0.t0', {}).get('DEVICE_ID', None),
            data.get('s0.t0', {}).get('DEVICE', None),
            data.get('s0.t0', {}).get('TOTAL_COPY_IN_SIZE_BYTES', None),
            data.get('s0.t0', {}).get('TASK_KERNEL_TIME', None)
        )

        # construct insert command
        sql = '''
        INSERT INTO Benchmark (
            RunId,
            TOTAL_TASK_GRAPH_TIME,
            COPY_IN_TIME,
            COPY_OUT_TIME,
            TOTAL_KERNEL_TIME,
            TOTAL_COPY_IN_SIZE_BYTES,
            TOTAL_COPY_OUT_SIZE_BYTES,
            DRIVER,
            METHOD,
            DEVICE_ID,
            DEVICE,
            TOTAL_COPY_IN_SIZE_BYTES,
            TASK_KERNEL_TIME
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)
        '''

        try:
            cur.execute(sql, benchmark_data)
            # submit changes
            db_conn.commit()
        except sqlite3.IntegrityError as e:
            print(f"Data insertion error: {e}")
            db_conn.rollback()

    cur.close()

